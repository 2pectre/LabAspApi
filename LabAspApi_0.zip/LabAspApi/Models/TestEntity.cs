namespace LabAspApi.Models
{
    public class TestEntity
    {
        public int Id { get; set; }
        public string? Test { get; set; }
    }
}
